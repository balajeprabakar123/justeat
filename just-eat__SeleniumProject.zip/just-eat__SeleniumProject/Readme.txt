1. Run this using TestCase.MenuPage java file u will view executions in chrome 

Scenarios covered:
1. login to application
2. verifyPinCodeSearch opens the search
3. verifyPinCodeSearchEntered is opening as expected
4. verifySearchResult by filter
5.verifySearchResultByValue
6. verifyPinCodeSearchChanged
