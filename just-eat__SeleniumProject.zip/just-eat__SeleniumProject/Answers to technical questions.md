Answers to technical questions
2.	How long did you spend on the technical test? What would you add to your solution if you had more time? If you didn't spend much time on the technical test then use this as an opportunity to explain what you would add.
2 hrs
3.	What do you think is the most interesting trend in test automation?
Learning new tools and facing new issues in automation and learning / finding solutions to fix it  
4.	How would you implement test automation in a legacy application? Have you ever had to do this?
Automate by having all normal scrnario used , then improvice by adding more regression
5.	How would you improve the customer experience of the JUST EAT website?
By having more interactive search and adding auto locate using plugins , getting ui more user friendly with option to checkout in easy way.

6.	Please describe yourself using JSON.


{
"name": "Balaje",
"lastname": "Sundaram Prabakar",
"age": 31,
"nationality": "Indian",
"livesin": "Hamilton",
"passions": [
"Automation",
"Teaching others","Learning new tools"
],
"interests": [
"Keeping Busy",
"Driving"
],

"dreams": [
"To be the best i work in every aspect!"
],

"believes": [
"We should all have open minded ,Never be judgemental in any decision!"
]
}

